param (
    [string]$OutputPath
)

$saidaFinal = Join-Path $OutputPath "usuarios_inativos.csv"
$limiteInatividade = (Get-Date).AddDays(-84)

$usuarios = Get-ADUser -Filter { lastLogonTimestamp -lt $limiteInatividade } -Properties SamAccountName, lastLogonTimestamp, UserAccountControl, DistinguishedName | ForEach-Object {
    if ($_.DistinguishedName -match '^CN=([^,]+),(.+)$') {
        $CN = $matches[1]
        $OU = $matches[2] -replace '(?i).*?OU=([^,]+).*', '$1'
        $StatusConta = if ($_.UserAccountControl -band 2) { "Inativo" } else { "Ativo" }
        [PSCustomObject]@{
            Usuario = $_.SamAccountName
            NomeCompleto = $CN
            OU = $OU
            Status = $StatusConta
            UltimoLogon = if ($_.lastLogonTimestamp) { [datetime]::FromFileTime($_.lastLogonTimestamp) } else { "Nunca logou" }
        }
    }
}

if ($usuarios.Count -gt 0) {
    $usuarios | Sort-Object OU, Status, Usuario | Export-Csv -Path $saidaFinal -NoTypeInformation -Encoding UTF8
}
