﻿# MCH_ActiveAudit - Script Principal de Auditoria de Active Directory
# Desenvolvido por Michael Oliveira

param (
    [string]$OutputPath = "C:\MCHAudit"
)

if (!(Test-Path $OutputPath)) {
    New-Item -Path $OutputPath -ItemType Directory | Out-Null
}

$ScriptBase = Split-Path -Parent $MyInvocation.MyCommand.Definition

$modules = @(
    "modules/Audit-InactiveUsers.ps1"
)

foreach ($module in $modules) {
    Write-Output "Executando modulo: $module"
    $fullPath = Join-Path $ScriptBase $module
    & $fullPath -OutputPath $OutputPath
}

# Gerar relatório HTML consolidado
$reportPath = Join-Path $OutputPath "relatorio_auditoria.html"
$htmlContent = @"
<html>
<head>
    <title>MCH Active Directory Audit Report</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        h1 { color: #004080; }
        table { border-collapse: collapse; width: 100%%; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #004080; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
    </style>
</head>
<body>
<h1> MCH Active Directory Audit Report</h1>
<p>Gerado em: $(Get-Date -Format "dd/MM/yyyy HH:mm")</p>
<table>
<tr><th>Categoria</th><th>Total</th><th>Arquivo CSV</th></tr>
"@

$csvFiles = @(
    @{ Nome = "Usuarios inativos ha 90+ dias"; Arquivo = "usuarios_inativos.csv" }
)

foreach ($item in $csvFiles) {
    $caminho = Join-Path $OutputPath $item.Arquivo
    if (Test-Path $caminho) {
        $total = (Import-Csv $caminho).Count
        $htmlContent += "<tr><td>$($item.Nome)</td><td>$total</td><td><a href='$($item.Arquivo)'>$($item.Arquivo)</a></td></tr>`n"
    }
}

$htmlContent += @"
</table>
<p style='margin-top:30px; font-size:small;'>Relatorio gerado automaticamente por <strong>MCHActiveAudit</strong> | Michael Oliveira - 2025</p>
</body>
</html>
"@

$htmlContent | Out-File -FilePath $reportPath -Encoding UTF8
Write-Output "Relatório HTML consolidado gerado em: $reportPath"
